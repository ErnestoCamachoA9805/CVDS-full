package edu.eci.pdsw.samples.entities;

public enum TipoIdentificacion {
    CC,
    CE,
    RC,
    TI
}
